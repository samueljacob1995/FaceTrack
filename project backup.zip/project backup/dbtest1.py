import psycopg2


def dbinsert(id,name):
    try:
        conn = psycopg2.connect(host="localhost",database="Users", user="postgres", password="password")

        cur = conn.cursor()
            # execute the INSERT statement
      
        cur.execute("""INSERT INTO users VALUES (%s,%s)""",(id,name))
        conn.commit()
            # close communication with the database
        cur.close()
    except (Exception, psycopg2.DatabaseError) as error:
        print(error)
    finally:
        if conn is not None:
            conn.close()

def dbget(id):
    try:
        conn = psycopg2.connect(host="localhost",database="Users", user="postgres", password="password")

        cur = conn.cursor()
            # execute the INSERT statement
      
        cur.execute("""SELECT name FROM users WHERE id = %s""",[id])
        str1 = str(cur.fetchone())
        #create list as mylist1 
        mylist1 = str1.split("'")
        name = mylist1[1]
        #print name
        return name
        #conn.commit()
            # close communication with the database
        #cur.close()
    except (Exception, psycopg2.DatabaseError) as error:
        print(error)
    finally:
        if conn is not None:
            conn.close()

def dbgetids():
    try:
        conn = psycopg2.connect(host="localhost",database="Users", user="postgres", password="password")

        cur = conn.cursor()
            # execute the INSERT statement
      
        cur.execute("""SELECT id from users""")
        mylist = []
        for row in cur:
            num = str(row)
            num = num.split("(")
            num = num[1].split(",")
            num = num [0]
            mylist.append(num)
        return mylist
        #conn.commit()
            # close communication with the database
        #cur.close()
    except (Exception, psycopg2.DatabaseError) as error:
        print(error)
    finally:
        if conn is not None:
            conn.close()
dbget(1)