import cv2
import numpy as np
import trainner

faceDetect = cv2.CascadeClassifier('trainner.yml')
cap = cv2.VideoCapture(0)

while(True):
    ret, img  = cap.read()
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    faces = faceDetect.detectMultiScale(gray,1.4,5)
    for(x,y,w,h) in faces:
        cv2.rectangle(img, (x,y), (x+w,y+h), (0,255,0),2)
        cv2.putText(img, 'Samuel', (x,y), cv2.FONT_HERSHEY_SIMPLEX, 1, (0,255,0))

    cv2.imshow('faces', img)
    if cv2.waitKey(1)&0xFF == ord('q'):
        break
cap.release()
cv2.destroyAllWindows()