import psycopg2

try:
    conn = psycopg2.connect(host="localhost",database="Users", user="postgres", password="password")

    cur = conn.cursor()
        # execute the INSERT statement
    
    #cur.execute("""INSERT INTO users VALUES (1,'Peter')""")
    cur.execute("""SELECT name from users where id = 1 """)
    str = str(cur.fetchone())
    #create list as mylist 
    mylist = str.split("'")
    print(mylist[1])
    conn.commit()
        # close communication with the database
    cur.close()
except (Exception, psycopg2.DatabaseError) as error:
    print(error)
finally:
    if conn is not None:
        conn.close()
 