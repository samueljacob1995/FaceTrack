import psycopg2

try:
    conn = psycopg2.connect(host="localhost",database="postgres", user="postgres", password="password")

    cur = conn.cursor()
        # execute the INSERT statement
    
    cur.execute("""INSERT INTO "Users" VALUES (3,'Samuel')""")
    cur.execute("""SELECT * from "Users" """)
    str = str(cur.fetchall())
    #create list as mylist 
    mylist = str.split("'")
    print(mylist)
    conn.commit()
        # close communication with the database
    cur.close()
except (Exception, psycopg2.DatabaseError) as error:
    print(error)
finally:
    if conn is not None:
        conn.close()
 