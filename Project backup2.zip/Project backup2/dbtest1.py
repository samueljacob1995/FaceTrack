import psycopg2


def dbinsert(id,name):
    try:
        conn = psycopg2.connect(host="localhost",database="postgres", user="postgres", password="password")

        cur = conn.cursor()
            # execute the INSERT statement
      
        cur.execute("""INSERT INTO "Users" VALUES (%s,%s)""",(id,name))
        conn.commit()
            # close communication with the database
        cur.close()
    except (Exception, psycopg2.DatabaseError) as error:
        print(error)
    finally:
        if conn is not None:
            conn.close()

def dbget(id):
    try:
        conn = psycopg2.connect(host="localhost",database="postgres", user="postgres", password="password")

        cur = conn.cursor()
            # execute the INSERT statement
      
        cur.execute("""SELECT "Username" FROM "Users" WHERE "ID" = %s""",[id])
        str1 = str(cur.fetchone())
        #create list as mylist1 
        mylist1 = str1.split("'")
        name = mylist1[1]
        #print name
        return name
        #conn.commit()
            # close communication with the database
        #cur.close()
    except (Exception, psycopg2.DatabaseError) as error:
        print(error)
    finally:
        if conn is not None:
            conn.close()

def dbgetids():
    try:
        conn = psycopg2.connect(host="localhost",database="postgres", user="postgres", password="password")

        cur = conn.cursor()
            # execute the INSERT statement
      
        cur.execute("""SELECT "ID" from "Users" """)
        mylist = set()
        for row in cur:
            num = str(row)
            num = num.split("(")
            num = num[1].split(",")
            num = num [0]
            mylist.add(num)
            #print(num)
        return mylist
        #conn.commit()
            # close communication with the database
        #cur.close()
    except (Exception, psycopg2.DatabaseError) as error:
        print(error)
    finally:
        if conn is not None:
            conn.close()
dbgetids()