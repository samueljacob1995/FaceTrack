import cv2
import numpy as np

img = cv2.imread('dog.jpg')

frame = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
cv2.imwrite("dogret11.jpg",frame)
frame = cv2.equalizeHist(frame)

while True:
    cv2.imshow('original frame',img)
    cv2.imshow('equalized',frame)
    cv2.imwrite("dogret21.jpg",frame)
    
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break
cv2.destroyAllWindows()