import cv2
import numpy as np
from dbtest1 import dbget, dbgetids

recognizer = cv2.createLBPHFaceRecognizer()
recognizer.load('trainner/trainner2.yml')
cascadePath = "haarcascade_frontalface_default.xml"
faceCascade = cv2.CascadeClassifier(cascadePath)


cam = cv2.VideoCapture(0)
font = cv2.cv.InitFont(cv2.cv.CV_FONT_HERSHEY_SIMPLEX, 0.5, 1, 0, 1, 1)
while True:
    ret, im =cam.read()
    if ret == True:
        img = im
        #illumination normalization
        #-----Converting image to LAB Color model----------------------------------- 
        lab= cv2.cvtColor(img, cv2.COLOR_BGR2LAB)
        #-----Splitting the LAB image to different channels-------------------------
        l, a, b = cv2.split(lab)
        #-----Applying CLAHE to L-channel-------------------------------------------
        clahe = cv2.createCLAHE(clipLimit=1.0, tileGridSize=(8,8))
        cl = clahe.apply(l)
        #-----Merge the CLAHE enhanced L-channel with the a and b channel-----------
        limg = cv2.merge((cl,a,b))
        #-----Converting image from LAB Color model to RGB model--------------------
        img = cv2.cvtColor(limg, cv2.COLOR_LAB2BGR)

        #histogram equalization
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        gray = cv2.equalizeHist(gray)
        faces=faceCascade.detectMultiScale(gray, 1.2,7)
        for(x,y,w,h) in faces:
            Id, conf = recognizer.predict(gray[y:y+h,x:x+w])
            if(conf < 50):
                cv2.rectangle(im,(x,y),(x+w,y+h+40),(0,255,0),2)
                cv2.rectangle(im,(x,y+h),(x+w,y+h+40),(0,255,0),-1)
                for Id in dbgetids():
                    name = dbget(Id)
                    #print(name)
                    Id = name + `int(conf)`
                    break
                    #print(Id)
                #else:
                #    cv2.rectangle(im,(x,y),(x+w,y+h+40),(0,0,255),2)
                #    cv2.rectangle(im,(x,y+h),(x+w,y+h+40),(0,0,255),-1)
                #    Id="Unknown" + `int(conf)`
            else:
                cv2.rectangle(im,(x,y),(x+w,y+h+40),(0,0,255),2)
                cv2.rectangle(im,(x,y+h),(x+w,y+h+40),(0,0,255),-1)
                Id="Unknown" + `int(conf)`
            cv2.cv.PutText(cv2.cv.fromarray(im),str(Id), (x,y+h+35),font, (255,255,255))
        cv2.imshow('im',im) 
        if cv2.waitKey(10) & 0xFF==ord('q'):
            break
cam.release()
cv2.destroyAllWindows()